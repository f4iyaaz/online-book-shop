import Homepage from "./components/Homepage";

function App() {
  return (
    <>
      <Homepage />
    </>
  );
}

export default App;
